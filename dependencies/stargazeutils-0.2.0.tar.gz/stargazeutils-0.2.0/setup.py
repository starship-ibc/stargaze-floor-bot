# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['stargazeutils',
 'stargazeutils.cache',
 'stargazeutils.collection',
 'stargazeutils.market']

package_data = \
{'': ['*']}

install_requires = \
['py-cid>=0.3.0,<0.4.0',
 'requests-cache>=0.9.3,<0.10.0',
 'requests>=2.27.1,<3.0.0']

setup_kwargs = {
    'name': 'stargazeutils',
    'version': '0.2.0',
    'description': '',
    'long_description': None,
    'author': 'Starship IBC',
    'author_email': 'shrugs.rest0x@icloud.com',
    'maintainer': None,
    'maintainer_email': None,
    'url': None,
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'python_requires': '>=3.10,<4.0',
}


setup(**setup_kwargs)
